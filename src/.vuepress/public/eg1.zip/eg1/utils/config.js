const base_url = "https://www.easy-mock.com/mock/5c2b2992f2332405dd956d1e/zhufeng";
export {
  base_url
}